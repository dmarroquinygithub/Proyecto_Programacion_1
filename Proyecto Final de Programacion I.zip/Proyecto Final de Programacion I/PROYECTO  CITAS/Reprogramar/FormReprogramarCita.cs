﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Agendar;
using PROYECTO__CITAS.Reprogramar;

namespace PROYECTO__CITAS
{
    public partial class FormReprogramarCita : Form
    {
        private int idCitaSeleccionada = -1;
        private ReprogramacionRepository repo = new ReprogramacionRepository();

        public FormReprogramarCita()
        {
            InitializeComponent();
        }

        private void FormReprogramarCita_Load(object sender, EventArgs e)
        {
            // Intencionalmente se deja vacío para que no se cargue nada al inicio
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            BuscarCitas();
        }

        private void BuscarCitas()
        {
            string filtro = txtBuscarDPI.Text.Trim();

            if (string.IsNullOrWhiteSpace(filtro))
            {
                MessageBox.Show("Por favor ingresa un número de DPI o nombre.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable resultados = repo.BuscarCitas(filtro);
            dgvCitas.DataSource = resultados;

            if (resultados.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron citas para el criterio ingresado.", "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void CargarCitas()
        {
            // Simplemente recarga usando la misma logica de busqueda
            BuscarCitas();
        }

        private void dgvCitas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    idCitaSeleccionada = Convert.ToInt32(dgvCitas.Rows[e.RowIndex].Cells["id_cita"].Value);
                    dtpNuevaFecha.Value = Convert.ToDateTime(dgvCitas.Rows[e.RowIndex].Cells["fecha_cita"].Value);
                    dtpNuevaHora.Value = DateTime.Today.Add(TimeSpan.Parse(dgvCitas.Rows[e.RowIndex].Cells["hora"].Value.ToString()));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al seleccionar cita: " + ex.Message);
                }
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (idCitaSeleccionada == -1)
            {
                MessageBox.Show("Por favor selecciona una cita primero.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DateTime nuevaFecha = dtpNuevaFecha.Value.Date;
                TimeSpan nuevaHora = dtpNuevaHora.Value.TimeOfDay;

                repo.ReprogramarCita(idCitaSeleccionada, nuevaFecha, nuevaHora);

                MessageBox.Show("La cita ha sido reprogramada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                CargarCitas();
                LimpiarCampos();

                // Refresca el historial si esta abierto
                foreach (Form form in Application.OpenForms)
                {
                    if (form is FormHistorialCita historialForm)
                    {
                        historialForm.Close();
                        new FormHistorialCita().Show();
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al guardar los cambios: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelarCita_Click(object sender, EventArgs e)
        {
            if (idCitaSeleccionada == -1)
            {
                MessageBox.Show("Seleccione una cita para cancelar.");
                return;
            }

            var confirmResult = MessageBox.Show("¿Está seguro de que desea cancelar esta cita?",
                                                "Confirmar Cancelación",
                                                MessageBoxButtons.YesNo,
                                                MessageBoxIcon.Warning);

            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    using (var conexion = new MySqlConnection("server=localhost;database=CitasMedicasDB;uid=root;pwd=123456789;"))
                    {
                        conexion.Open();
                        string query = "DELETE FROM Citas WHERE id_cita = @idCita";
                        using (var cmd = new MySqlCommand(query, conexion))
                        {
                            cmd.Parameters.AddWithValue("@idCita", idCitaSeleccionada);
                            int resultado = cmd.ExecuteNonQuery();

                            if (resultado > 0)
                            {
                                MessageBox.Show("Cita cancelada correctamente.");
                                CargarCitas();
                                LimpiarCampos();
                            }
                            else
                            {
                                MessageBox.Show("No se pudo cancelar la cita.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cancelar la cita: " + ex.Message);
                }
            }
        }

        private void LimpiarCampos()
        {
            idCitaSeleccionada = -1;
            dtpNuevaFecha.Value = DateTime.Today;
            dtpNuevaHora.Value = DateTime.Now;
        }

        private void dtpNuevaHora_ValueChanged(object sender, EventArgs e) { }

        private void label2_Click(object sender, EventArgs e) { }
    }
}