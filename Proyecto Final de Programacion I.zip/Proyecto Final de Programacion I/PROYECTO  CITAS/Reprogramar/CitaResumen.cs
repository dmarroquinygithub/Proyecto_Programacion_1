﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO__CITAS.Reprogramar
{
    internal class CitaResumen
    {
        public int IdCita { get; set; }
        public string NombrePaciente { get; set; }
        public DateTime FechaCita { get; set; }
        public TimeSpan Hora { get; set; }
        public string NombreMedico { get; set; }
    }
}
