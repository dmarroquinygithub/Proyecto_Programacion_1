﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Agendar;

namespace PROYECTO__CITAS.Reprogramar
{
    internal class ReprogramacionRepository
    {
        public DataTable BuscarCitas(string filtro)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string query = @"
            SELECT c.id_cita, c.nombre_paciente, c.fecha_cita, c.hora, m.nombre AS medico
            FROM Citas c
            JOIN Medicos m ON c.id_medico = m.id_medico
            WHERE c.dpi = @filtro OR LOWER(c.nombre_paciente) LIKE LOWER(@nombre)";

                MySqlCommand cmd = new MySqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@filtro", filtro); // Búsqueda exacta por DPI
                cmd.Parameters.AddWithValue("@nombre", "%" + filtro + "%"); // Búsqueda parcial por nombre
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public void ReprogramarCita(int idCita, DateTime nuevaFecha, TimeSpan nuevaHora)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string query = "UPDATE Citas SET fecha_cita = @fecha, hora = @hora WHERE id_cita = @id";

                MySqlCommand cmd = new MySqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@fecha", nuevaFecha.Date);
                cmd.Parameters.AddWithValue("@hora", nuevaHora);
                cmd.Parameters.AddWithValue("@id", idCita);
                cmd.ExecuteNonQuery();
            }
        }
        public bool EliminarCita(int idCita)
        {
            using (var conexion = new MySqlConnection("server=localhost;database=CitasMedicasDB;uid=root;pwd=123456789;"))
            {
                conexion.Open();
                string query = "DELETE FROM Citas WHERE id_cita = @idCita";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@idCita", idCita);
                    int filasAfectadas = comando.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
            }
        }
    }
}

