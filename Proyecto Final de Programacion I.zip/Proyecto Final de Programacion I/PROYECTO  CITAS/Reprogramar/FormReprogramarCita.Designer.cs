﻿namespace PROYECTO__CITAS
{
    partial class FormReprogramarCita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBuscarDPI = new TextBox();
            btnBuscar = new Button();
            dgvCitas = new DataGridView();
            dtpNuevaHora = new DateTimePicker();
            dtpNuevaFecha = new DateTimePicker();
            btnActualizar = new Button();
            label1 = new Label();
            label2 = new Label();
            btnCancelarCita = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvCitas).BeginInit();
            SuspendLayout();
            // 
            // txtBuscarDPI
            // 
            txtBuscarDPI.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBuscarDPI.Location = new Point(22, 89);
            txtBuscarDPI.Margin = new Padding(2, 3, 2, 3);
            txtBuscarDPI.Name = "txtBuscarDPI";
            txtBuscarDPI.Size = new Size(297, 30);
            txtBuscarDPI.TabIndex = 0;
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = Color.FromArgb(74, 144, 226);
            btnBuscar.FlatStyle = FlatStyle.Flat;
            btnBuscar.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBuscar.ForeColor = Color.White;
            btnBuscar.Location = new Point(345, 83);
            btnBuscar.Margin = new Padding(2, 3, 2, 3);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(142, 36);
            btnBuscar.TabIndex = 1;
            btnBuscar.Text = "Buscar Cita";
            btnBuscar.UseVisualStyleBackColor = false;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // dgvCitas
            // 
            dgvCitas.BackgroundColor = Color.FromArgb(249, 250, 251);
            dgvCitas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCitas.Location = new Point(22, 429);
            dgvCitas.Margin = new Padding(2, 3, 2, 3);
            dgvCitas.Name = "dgvCitas";
            dgvCitas.RowHeadersWidth = 62;
            dgvCitas.Size = new Size(910, 291);
            dgvCitas.TabIndex = 2;
            dgvCitas.CellClick += dgvCitas_CellClick;
            // 
            // dtpNuevaHora
            // 
            dtpNuevaHora.CalendarFont = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpNuevaHora.Format = DateTimePickerFormat.Time;
            dtpNuevaHora.Location = new Point(22, 163);
            dtpNuevaHora.Margin = new Padding(2, 3, 2, 3);
            dtpNuevaHora.Name = "dtpNuevaHora";
            dtpNuevaHora.ShowUpDown = true;
            dtpNuevaHora.Size = new Size(265, 27);
            dtpNuevaHora.TabIndex = 3;
            dtpNuevaHora.ValueChanged += dtpNuevaHora_ValueChanged;
            // 
            // dtpNuevaFecha
            // 
            dtpNuevaFecha.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpNuevaFecha.Location = new Point(535, 89);
            dtpNuevaFecha.Margin = new Padding(2, 3, 2, 3);
            dtpNuevaFecha.Name = "dtpNuevaFecha";
            dtpNuevaFecha.Size = new Size(362, 30);
            dtpNuevaFecha.TabIndex = 4;
            // 
            // btnActualizar
            // 
            btnActualizar.BackColor = Color.FromArgb(74, 144, 226);
            btnActualizar.FlatStyle = FlatStyle.Flat;
            btnActualizar.Font = new Font("Arial", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnActualizar.ForeColor = Color.White;
            btnActualizar.Location = new Point(803, 347);
            btnActualizar.Margin = new Padding(2, 3, 2, 3);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(129, 45);
            btnActualizar.TabIndex = 5;
            btnActualizar.Text = "Guardar Cambios";
            btnActualizar.UseVisualStyleBackColor = false;
            btnActualizar.Click += btnActualizar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 47);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(239, 26);
            label1.TabIndex = 6;
            label1.Text = "Ingresar Nombre / DPI";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(535, 47);
            label2.Name = "label2";
            label2.Size = new Size(123, 26);
            label2.TabIndex = 7;
            label2.Text = "Dia, Fecha";
            label2.Click += label2_Click;
            // 
            // btnCancelarCita
            // 
            btnCancelarCita.BackColor = Color.FromArgb(74, 144, 226);
            btnCancelarCita.FlatStyle = FlatStyle.Flat;
            btnCancelarCita.Font = new Font("Arial", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCancelarCita.ForeColor = Color.White;
            btnCancelarCita.Location = new Point(22, 347);
            btnCancelarCita.Margin = new Padding(3, 4, 3, 4);
            btnCancelarCita.Name = "btnCancelarCita";
            btnCancelarCita.Size = new Size(128, 45);
            btnCancelarCita.TabIndex = 8;
            btnCancelarCita.Text = "Eliminar Cita";
            btnCancelarCita.UseVisualStyleBackColor = false;
            btnCancelarCita.Click += btnCancelarCita_Click;
            // 
            // FormReprogramarCita
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 241, 249);
            ClientSize = new Size(967, 748);
            Controls.Add(btnCancelarCita);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnActualizar);
            Controls.Add(dtpNuevaFecha);
            Controls.Add(dtpNuevaHora);
            Controls.Add(dgvCitas);
            Controls.Add(btnBuscar);
            Controls.Add(txtBuscarDPI);
            Margin = new Padding(2, 3, 2, 3);
            Name = "FormReprogramarCita";
            Text = "FormReprogramarCita";
            Load += FormReprogramarCita_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCitas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBuscarDPI;
        private Button btnBuscar;
        private DataGridView dgvCitas;
        private DateTimePicker dtpNuevaHora;
        private DateTimePicker dtpNuevaFecha;
        private Button btnActualizar;
        private Label label1;
        private Label label2;
        private Button btnCancelarCita;
       
    }
}