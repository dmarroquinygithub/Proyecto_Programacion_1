﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Agendar;

namespace PROYECTO__CITAS.Reporte
{
    internal class ReporteRepository
    {
        public DataTable ObtenerMedicos()
        {
            using (var conn = ConexionBD.ObtenerConexion())
            {
                string query = "SELECT id_medico, nombre FROM Medicos";
                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataTable ObtenerCitas(DateTime desde, DateTime hasta, int? idMedico = null)
        {
            using (var conn = ConexionBD.ObtenerConexion())
            {
                string query = @"
                    SELECT c.id_cita, c.nombre_paciente, c.apellido_paciente, c.dpi,
                           c.fecha_cita, c.hora, c.motivo, m.nombre AS medico
                    FROM Citas c
                    INNER JOIN Medicos m ON c.id_medico = m.id_medico
                    WHERE (c.fecha_cita BETWEEN @desde AND @hasta)";

                if (idMedico.HasValue)
                    query += " AND m.id_medico = @id_medico";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@desde", desde);
                cmd.Parameters.AddWithValue("@hasta", hasta);

                if (idMedico.HasValue)
                    cmd.Parameters.AddWithValue("@id_medico", idMedico.Value);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}

