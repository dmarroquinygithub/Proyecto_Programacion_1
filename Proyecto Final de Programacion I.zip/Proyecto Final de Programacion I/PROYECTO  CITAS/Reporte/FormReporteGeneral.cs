﻿using System;
using System.Data;
using System.Windows.Forms;
using PROYECTO__CITAS.Agendar;
using PROYECTO__CITAS.Reporte;
using PROYECTO__CITAS.Registro;

namespace PROYECTO__CITAS
{
    public partial class FormReporteGeneral : Form
    {
        private ReporteRepository repo = new ReporteRepository();

        public FormReporteGeneral()
        {
            InitializeComponent();
        }

        private void FormReporteGeneral_Load(object sender, EventArgs e)
        {
            CargarMedicos();

            dgvReporte.DataSource = null;


            dgvReporte.AllowUserToAddRows = false;

            // Mejora lo visual con el autoajuste de columnas
            dgvReporte.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void CargarMedicos()
        {
            var dt = repo.ObtenerMedicos();

            // Crea las filas personalizada para "Todos los médicos"
            DataRow filaTodos = dt.NewRow();
            filaTodos["id_medico"] = DBNull.Value; // o 0 si tu campo no permite null
            filaTodos["nombre"] = "Todos los médicos";

            // Inserta al inicio las filas
            dt.Rows.InsertAt(filaTodos, 0);

            // Se asigna un comboBox para los médicos
            cbMedico.DisplayMember = "nombre";
            cbMedico.ValueMember = "id_medico";
            cbMedico.DataSource = dt;
        }

        private void CargarCitas()
        {
            // Obteniene el ID del médico seleccionado (o null si es "Todos")
            int? idMedico = cbMedico.SelectedIndex > 0 ? (int?)Convert.ToInt32(cbMedico.SelectedValue) : null;

            // Se obtiene el rango de fechas
            DateTime fechaDesde = dtpDesde.Value.Date;
            DateTime fechaHasta = dtpHasta.Value.Date;

            // Se obtenien los datos desde la base
            DataTable resultados = repo.ObtenerCitas(fechaDesde, fechaHasta, idMedico);

            // Muestra los resultados en el DataGridView
            dgvReporte.DataSource = resultados;

            // Limpia la seleccion actual
            dgvReporte.ClearSelection();

            // Muestra un mensaje si no hay resultados
            if (resultados.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron citas en el rango seleccionado.", "Sin resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            CargarCitas();
        }

        private void btnExportarPDF_Click(object sender, EventArgs e)
        {
            ExportadorPDF.ExportarDataGridView(dgvReporte, "Reporte General de Citas", "ReporteCitas.pdf");
        }
    }
}