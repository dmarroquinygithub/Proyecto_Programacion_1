﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO__CITAS.Reporte
{
    internal class CitaReporte
    {
        public int IdCita { get; set; }
        public string NombrePaciente { get; set; }
        public string ApellidoPaciente { get; set; }
        public string DPI { get; set; }
        public DateTime FechaCita { get; set; }
        public TimeSpan Hora { get; set; }
        public string Motivo { get; set; }
        public string NombreMedico { get; set; }
    }
}
