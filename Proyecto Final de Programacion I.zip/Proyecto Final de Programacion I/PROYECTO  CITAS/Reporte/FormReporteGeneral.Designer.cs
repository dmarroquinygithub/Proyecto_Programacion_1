﻿namespace PROYECTO__CITAS
{
    partial class FormReporteGeneral
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            cbMedico = new ComboBox();
            dtpDesde = new DateTimePicker();
            dtpHasta = new DateTimePicker();
            btnFiltrar = new Button();
            dgvReporte = new DataGridView();
            label1 = new Label();
            btnExportarPDF = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvReporte).BeginInit();
            SuspendLayout();
            // 
            // cbMedico
            // 
            cbMedico.FormattingEnabled = true;
            cbMedico.Location = new Point(41, 92);
            cbMedico.Name = "cbMedico";
            cbMedico.Size = new Size(324, 28);
            cbMedico.TabIndex = 0;
            // 
            // dtpDesde
            // 
            dtpDesde.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpDesde.Location = new Point(466, 90);
            dtpDesde.Name = "dtpDesde";
            dtpDesde.Size = new Size(353, 30);
            dtpDesde.TabIndex = 1;
            // 
            // dtpHasta
            // 
            dtpHasta.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpHasta.Location = new Point(41, 218);
            dtpHasta.Name = "dtpHasta";
            dtpHasta.Size = new Size(353, 30);
            dtpHasta.TabIndex = 2;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnFiltrar.BackColor = Color.FromArgb(74, 144, 226);
            btnFiltrar.FlatStyle = FlatStyle.Flat;
            btnFiltrar.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnFiltrar.ForeColor = Color.White;
            btnFiltrar.Location = new Point(757, 236);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(159, 42);
            btnFiltrar.TabIndex = 3;
            btnFiltrar.Text = "Buscar";
            btnFiltrar.UseVisualStyleBackColor = false;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // dgvReporte
            // 
            dgvReporte.AllowUserToAddRows = false;
            dgvReporte.AllowUserToDeleteRows = false;
            dgvReporte.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvReporte.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvReporte.BackgroundColor = Color.FromArgb(249, 250, 251);
            dgvReporte.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvReporte.Location = new Point(29, 368);
            dgvReporte.Name = "dgvReporte";
            dgvReporte.RowHeadersWidth = 62;
            dgvReporte.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvReporte.Size = new Size(887, 262);
            dgvReporte.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(232, 241, 249);
            label1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(41, 49);
            label1.Name = "label1";
            label1.Size = new Size(184, 26);
            label1.TabIndex = 5;
            label1.Text = "Lista de Medicos";
            // 
            // btnExportarPDF
            // 
            btnExportarPDF.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnExportarPDF.BackColor = Color.FromArgb(74, 144, 226);
            btnExportarPDF.FlatStyle = FlatStyle.Flat;
            btnExportarPDF.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnExportarPDF.ForeColor = Color.White;
            btnExportarPDF.Location = new Point(710, 651);
            btnExportarPDF.Name = "btnExportarPDF";
            btnExportarPDF.Size = new Size(206, 42);
            btnExportarPDF.TabIndex = 6;
            btnExportarPDF.Text = "Exportar a PDF";
            btnExportarPDF.UseVisualStyleBackColor = false;
            btnExportarPDF.Click += btnExportarPDF_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(466, 49);
            label2.Name = "label2";
            label2.Size = new Size(231, 26);
            label2.TabIndex = 7;
            label2.Text = "Filtrar desde la Fecha";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(41, 179);
            label3.Name = "label3";
            label3.Size = new Size(166, 26);
            label3.TabIndex = 8;
            label3.Text = "Hasta la Fecha";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(498, 135);
            label4.Name = "label4";
            label4.Size = new Size(281, 26);
            label4.TabIndex = 9;
            label4.Text = "Dia,          Mes,             Año";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(69, 263);
            label5.Name = "label5";
            label5.Size = new Size(281, 26);
            label5.TabIndex = 10;
            label5.Text = "Dia,          Mes,             Año";
            // 
            // FormReporteGeneral
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(967, 748);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnExportarPDF);
            Controls.Add(label1);
            Controls.Add(dgvReporte);
            Controls.Add(btnFiltrar);
            Controls.Add(dtpHasta);
            Controls.Add(dtpDesde);
            Controls.Add(cbMedico);
            Name = "FormReporteGeneral";
            Text = "Reporte General";
            Load += FormReporteGeneral_Load;
            ((System.ComponentModel.ISupportInitialize)dgvReporte).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox cbMedico;
        private System.Windows.Forms.DateTimePicker dtpDesde;
        private System.Windows.Forms.DateTimePicker dtpHasta;
        private System.Windows.Forms.Button btnFiltrar;
        private System.Windows.Forms.DataGridView dgvReporte;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExportarPDF;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
