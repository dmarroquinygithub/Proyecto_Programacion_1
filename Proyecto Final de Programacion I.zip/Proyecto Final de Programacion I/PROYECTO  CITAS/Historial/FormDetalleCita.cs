﻿using System;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Windows.Forms;
using PROYECTO__CITAS.Historial;
using PROYECTO__CITAS.Agendar;

namespace PROYECTO__CITAS.Historial
{
    public partial class FormDetalleCita : Form
    {
        private int idCita;
        private HistorialRepository repo = new HistorialRepository();

        public FormDetalleCita(int citaId)
        {
            InitializeComponent();
            idCita = citaId;
        }

        private void FormDetalleCita_Load(object sender, EventArgs e)
        {
            CargarDetalle();
        }

        private void CargarDetalle()
        {
            CitaDetalle detalle = repo.ObtenerDetallePorId(idCita);

            if (detalle == null)
            {
                MessageBox.Show("No se encontraron detalles para esta cita.");
                this.Close();
                return;
            }

            // Carga los datos en las etiquetas del TableLayoutPanel
            lblPaciente.Text = $"{detalle.NombrePaciente} {detalle.ApellidoPaciente}";
            lblTelefono.Text = detalle.Telefono;
            lblDPI.Text = detalle.DPI;
            lblNacimiento.Text = detalle.FechaNacimiento.ToShortDateString();
            lblSexo.Text = detalle.Sexo;
            lblFecha.Text = detalle.FechaCita.ToShortDateString();
            lblHora.Text = detalle.Hora.ToString(@"hh\:mm");
            lblMotivo.Text = detalle.Motivo;
            lblMedico.Text = $"{detalle.NombreMedico} ({detalle.EspecialidadMedico})";
        }

        private void BtnExportarPDF_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog
            {
                Filter = "Archivo PDF (*.pdf)|*.pdf",
                FileName = "DetalleCita.pdf"
            };

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                ExportarCitaAPDF(saveFile.FileName);
            }
        }

        private void ExportarCitaAPDF(string ruta)
        {
            Document doc = new Document(PageSize.A4, 50, 50, 50, 50);

            try
            {
                PdfWriter.GetInstance(doc, new FileStream(ruta, FileMode.Create));
                doc.Open();

                var titulo = new Paragraph("Detalle de la Cita Médica", FontFactory.GetFont("Arial", 16, iTextSharp.text.Font.BOLD))
                {
                    Alignment = Element.ALIGN_CENTER
                };
                doc.Add(titulo);
                doc.Add(new Paragraph("\n"));

                PdfPTable tabla = new PdfPTable(2)
                {
                    WidthPercentage = 100
                };

                iTextSharp.text.Font fontCampo = FontFactory.GetFont("Arial", 11, iTextSharp.text.Font.BOLD);
                iTextSharp.text.Font fontValor = FontFactory.GetFont("Arial", 11);

                void AgregarFila(string campo, string valor)
                {
                    tabla.AddCell(new PdfPCell(new Phrase(campo, fontCampo)) { Border = 0, Padding = 5f });
                    tabla.AddCell(new PdfPCell(new Phrase(valor, fontValor)) { Border = 0, Padding = 5f });
                }

                AgregarFila("Nombre del Paciente", lblPaciente.Text);
                AgregarFila("Teléfono", lblTelefono.Text);
                AgregarFila("DPI", lblDPI.Text);
                AgregarFila("Fecha de Nacimiento", lblNacimiento.Text);
                AgregarFila("Sexo", lblSexo.Text);
                AgregarFila("Fecha", lblFecha.Text);
                AgregarFila("Hora", lblHora.Text);
                AgregarFila("Motivo", lblMotivo.Text);
                AgregarFila("Doctor", lblMedico.Text);

                doc.Add(tabla);
                doc.Add(new Paragraph("\nGenerado el " + DateTime.Now.ToShortDateString(), fontValor));

                MessageBox.Show("PDF generado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el PDF: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                doc.Close();
            }
        }


    }
}