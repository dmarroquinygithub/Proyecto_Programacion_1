﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using PROYECTO__CITAS.Registro;
using PROYECTO__CITAS.Historial;



namespace PROYECTO__CITAS
{
    public partial class FormHistorialCita : Form
    {
        private HistorialRepository repo = new HistorialRepository();

        public FormHistorialCita()
        {
            InitializeComponent();
            CargarHistorial();
        }

        private void CargarHistorial(string filtro = "")
        {
            DataTable dt = repo.ObtenerHistorial(filtro);
            dgvHistorial.DataSource = dt;

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron citas médicas.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string filtro = txtBuscar.Text.Trim();

            if (string.IsNullOrWhiteSpace(filtro))
            {
                MessageBox.Show("Por favor ingrese un criterio de búsqueda.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CargarHistorial(filtro);

            txtBuscar.Clear();
        }


        private void btnExportarPDF_Click(object sender, EventArgs e)
        {
            if (dgvHistorial.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            SaveFileDialog saveFile = new SaveFileDialog
            {
                Filter = "Archivo PDF (*.pdf)|*.pdf",
                FileName = "HistorialCitas.pdf"
            };

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                ExportarHistorialAPDF(saveFile.FileName);
            }
        }

        private void ExportarHistorialAPDF(string filePath)
        {
            Document doc = new Document(PageSize.A4.Rotate(), 20f, 20f, 20f, 20f);

            try
            {
                PdfWriter.GetInstance(doc, new FileStream(filePath, FileMode.Create));
                doc.Open();

                // El titulo
                Paragraph titulo = new Paragraph("Historial de Citas del Paciente", FontFactory.GetFont("Arial", 16, iTextSharp.text.Font.BOLD));
                titulo.Alignment = Element.ALIGN_CENTER;
                doc.Add(titulo);
                doc.Add(new Paragraph("\n"));

                // Generador de tabla para PDF
                PdfPTable pdfTable = new PdfPTable(dgvHistorial.Columns.Count)
                {
                    WidthPercentage = 100,
                    HorizontalAlignment = Element.ALIGN_CENTER
                };

                iTextSharp.text.Font fontHeader = FontFactory.GetFont("Arial", 11, iTextSharp.text.Font.BOLD);
                iTextSharp.text.Font fontCell = FontFactory.GetFont("Arial", 10);

                // Agrega los encabezados
                foreach (DataGridViewColumn column in dgvHistorial.Columns)
                {
                    PdfPCell headerCell = new PdfPCell(new Phrase(column.HeaderText, fontHeader))
                    {
                        BackgroundColor = new BaseColor(200, 200, 200),
                        Padding = 5
                    };
                    pdfTable.AddCell(headerCell);
                }

                // Agrega las filas
                foreach (DataGridViewRow row in dgvHistorial.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            string texto = cell.Value?.ToString() ?? "";
                            PdfPCell cellPdf = new PdfPCell(new Phrase(texto, fontCell))
                            {
                                Padding = 4
                            };
                            pdfTable.AddCell(cellPdf);
                        }
                    }
                }

                doc.Add(pdfTable);

                // Agrega el pie de pagina con fecha
                doc.Add(new Paragraph($"\nPDF generado el {DateTime.Now.ToShortDateString()}", fontCell));

                MessageBox.Show("PDF generado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar PDF: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                doc.Close();
            }
        }

        private void btnVerDetalle_Click(object sender, EventArgs e)
        {
            if (dgvHistorial.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona una cita primero.");
                return;
            }

            int idCita = Convert.ToInt32(dgvHistorial.SelectedRows[0].Cells["id_cita"].Value);
            FormDetalleCita detalle = new FormDetalleCita(idCita);
            detalle.ShowDialog();
        }
    }
}