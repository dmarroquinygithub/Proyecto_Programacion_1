﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Historial;
using PROYECTO__CITAS.Agendar;


namespace PROYECTO__CITAS.Historial
{
    internal class HistorialRepository
    {
        public DataTable ObtenerHistorial(string filtro = "")
        {
            using (var conn = ConexionBD.ObtenerConexion())
            {
                string query = @"
                    SELECT c.id_cita, c.nombre_paciente, c.apellido_paciente, c.dpi,
                           c.fecha_cita, c.hora, c.motivo,
                           m.nombre AS medico
                    FROM Citas c
                    INNER JOIN Medicos m ON c.id_medico = m.id_medico";

                if (!string.IsNullOrEmpty(filtro))
                {
                    query += " WHERE c.nombre_paciente LIKE @filtro OR c.apellido_paciente LIKE @filtro OR c.dpi LIKE @filtro OR m.nombre LIKE @filtro";
                }

                query += " ORDER BY c.fecha_cita DESC";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                if (!string.IsNullOrEmpty(filtro))
                {
                    cmd.Parameters.AddWithValue("@filtro", $"%{filtro}%");
                }

                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
        }

        public CitaDetalle ObtenerDetallePorId(int idCita)
        {
            using (var conn = ConexionBD.ObtenerConexion())
            {
                string query = @"
                    SELECT c.nombre_paciente, c.apellido_paciente, c.telefono, c.dpi, c.fecha_nacimiento,
                           c.sexo, c.fecha_cita, c.hora, c.motivo,
                           m.nombre AS medico, m.especialidad
                    FROM Citas c
                    JOIN Medicos m ON c.id_medico = m.id_medico
                    WHERE c.id_cita = @id";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idCita);

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new CitaDetalle
                        {
                            NombrePaciente = reader["nombre_paciente"].ToString(),
                            ApellidoPaciente = reader["apellido_paciente"].ToString(),
                            Telefono = reader["telefono"].ToString(),
                            DPI = reader["dpi"].ToString(),
                            FechaNacimiento = Convert.ToDateTime(reader["fecha_nacimiento"]),
                            Sexo = reader["sexo"].ToString(),
                            FechaCita = Convert.ToDateTime(reader["fecha_cita"]),
                            Hora = TimeSpan.Parse(reader["hora"].ToString()),
                            Motivo = reader["motivo"].ToString(),
                            NombreMedico = reader["medico"].ToString(),
                            EspecialidadMedico = reader["especialidad"].ToString()
                        };
                    }
                }
            }

            return null;
        }
    }
}

