﻿namespace PROYECTO__CITAS.Historial
{
    partial class FormDetalleCita
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private Label lblTitulo;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lblPaciente;
        private Label lblTelefono;
        private Label lblDPI;
        private Label lblNacimiento;
        private Label lblSexo;
        private Label lblFecha;
        private Label lblHora;
        private Label lblMotivo;
        private Label lblMedico;
        private Button btnExportarPDF;


        private void InitializeComponent()
        {
            lblTitulo = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            lblPaciente = new Label();
            lblTelefono = new Label();
            lblDPI = new Label();
            lblNacimiento = new Label();
            lblSexo = new Label();
            lblFecha = new Label();
            lblHora = new Label();
            lblMotivo = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            lblMedico = new Label();
            label9 = new Label();
            btnExportarPDF = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Dock = DockStyle.Top;
            lblTitulo.Font = new Font("Arial", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(0, 0);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(238, 32);
            lblTitulo.TabIndex = 1;
            lblTitulo.Text = "Detalles de la Cita";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.AutoSize = true;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            tableLayoutPanel1.Controls.Add(lblPaciente, 1, 0);
            tableLayoutPanel1.Controls.Add(lblTelefono, 1, 1);
            tableLayoutPanel1.Controls.Add(lblDPI, 1, 2);
            tableLayoutPanel1.Controls.Add(lblNacimiento, 1, 3);
            tableLayoutPanel1.Controls.Add(lblSexo, 1, 4);
            tableLayoutPanel1.Controls.Add(lblFecha, 1, 5);
            tableLayoutPanel1.Controls.Add(lblHora, 1, 6);
            tableLayoutPanel1.Controls.Add(lblMotivo, 1, 7);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Controls.Add(label3, 0, 2);
            tableLayoutPanel1.Controls.Add(label4, 0, 3);
            tableLayoutPanel1.Controls.Add(label5, 0, 4);
            tableLayoutPanel1.Controls.Add(label6, 0, 5);
            tableLayoutPanel1.Controls.Add(label7, 0, 6);
            tableLayoutPanel1.Controls.Add(label8, 0, 7);
            tableLayoutPanel1.Controls.Add(lblMedico, 1, 8);
            tableLayoutPanel1.Controls.Add(label9, 0, 8);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tableLayoutPanel1.Location = new Point(0, 32);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.Padding = new Padding(30);
            tableLayoutPanel1.RowCount = 9;
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(967, 716);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // lblPaciente
            // 
            lblPaciente.Anchor = AnchorStyles.Left;
            lblPaciente.AutoSize = true;
            lblPaciente.Font = new Font("Segoe UI", 10F);
            lblPaciente.Location = new Point(395, 32);
            lblPaciente.Name = "lblPaciente";
            lblPaciente.Size = new Size(0, 23);
            lblPaciente.TabIndex = 1;
            // 
            // lblTelefono
            // 
            lblTelefono.Anchor = AnchorStyles.Left;
            lblTelefono.AutoSize = true;
            lblTelefono.Font = new Font("Segoe UI", 10F);
            lblTelefono.Location = new Point(395, 60);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(0, 23);
            lblTelefono.TabIndex = 3;
            // 
            // lblDPI
            // 
            lblDPI.Anchor = AnchorStyles.Left;
            lblDPI.AutoSize = true;
            lblDPI.Font = new Font("Segoe UI", 10F);
            lblDPI.Location = new Point(395, 88);
            lblDPI.Name = "lblDPI";
            lblDPI.Size = new Size(0, 23);
            lblDPI.TabIndex = 5;
            // 
            // lblNacimiento
            // 
            lblNacimiento.Anchor = AnchorStyles.Left;
            lblNacimiento.AutoSize = true;
            lblNacimiento.Font = new Font("Segoe UI", 10F);
            lblNacimiento.Location = new Point(395, 116);
            lblNacimiento.Name = "lblNacimiento";
            lblNacimiento.Size = new Size(0, 23);
            lblNacimiento.TabIndex = 7;
            // 
            // lblSexo
            // 
            lblSexo.Anchor = AnchorStyles.Left;
            lblSexo.AutoSize = true;
            lblSexo.Font = new Font("Segoe UI", 10F);
            lblSexo.Location = new Point(395, 144);
            lblSexo.Name = "lblSexo";
            lblSexo.Size = new Size(0, 23);
            lblSexo.TabIndex = 9;
            // 
            // lblFecha
            // 
            lblFecha.Anchor = AnchorStyles.Left;
            lblFecha.AutoSize = true;
            lblFecha.Font = new Font("Segoe UI", 10F);
            lblFecha.Location = new Point(395, 172);
            lblFecha.Name = "lblFecha";
            lblFecha.Size = new Size(0, 23);
            lblFecha.TabIndex = 11;
            // 
            // lblHora
            // 
            lblHora.Anchor = AnchorStyles.Left;
            lblHora.AutoSize = true;
            lblHora.Font = new Font("Segoe UI", 10F);
            lblHora.Location = new Point(395, 200);
            lblHora.Name = "lblHora";
            lblHora.Size = new Size(0, 23);
            lblHora.TabIndex = 13;
            // 
            // lblMotivo
            // 
            lblMotivo.Anchor = AnchorStyles.Left;
            lblMotivo.AutoSize = true;
            lblMotivo.Font = new Font("Segoe UI", 10F);
            lblMotivo.Location = new Point(395, 228);
            lblMotivo.Name = "lblMotivo";
            lblMotivo.Size = new Size(0, 23);
            lblMotivo.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 30);
            label1.Name = "label1";
            label1.Size = new Size(198, 28);
            label1.TabIndex = 2;
            label1.Text = "Nombre del Paciente:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(33, 58);
            label2.Name = "label2";
            label2.Size = new Size(90, 28);
            label2.TabIndex = 18;
            label2.Text = "Telefono:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 86);
            label3.Name = "label3";
            label3.Size = new Size(46, 28);
            label3.TabIndex = 19;
            label3.Text = "DPI:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(33, 114);
            label4.Name = "label4";
            label4.Size = new Size(199, 28);
            label4.TabIndex = 20;
            label4.Text = "Fecha de Nacimiento:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(33, 142);
            label5.Name = "label5";
            label5.Size = new Size(58, 28);
            label5.TabIndex = 21;
            label5.Text = "Sexo:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(33, 170);
            label6.Name = "label6";
            label6.Size = new Size(66, 28);
            label6.TabIndex = 22;
            label6.Text = "Fecha:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(33, 198);
            label7.Name = "label7";
            label7.Size = new Size(59, 28);
            label7.TabIndex = 23;
            label7.Text = "Hora:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(33, 226);
            label8.Name = "label8";
            label8.Size = new Size(80, 28);
            label8.TabIndex = 24;
            label8.Text = "Motivo:";
            // 
            // lblMedico
            // 
            lblMedico.Anchor = AnchorStyles.Left;
            lblMedico.AutoSize = true;
            lblMedico.Font = new Font("Segoe UI", 10F);
            lblMedico.Location = new Point(395, 458);
            lblMedico.Name = "lblMedico";
            lblMedico.Size = new Size(0, 23);
            lblMedico.TabIndex = 17;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(33, 254);
            label9.Name = "label9";
            label9.Size = new Size(77, 28);
            label9.TabIndex = 25;
            label9.Text = "Doctor:";
            // 
            // btnExportarPDF
            // 
            btnExportarPDF.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnExportarPDF.BackColor = Color.FromArgb(0, 120, 215);
            btnExportarPDF.FlatStyle = FlatStyle.Flat;
            btnExportarPDF.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnExportarPDF.ForeColor = Color.White;
            btnExportarPDF.Location = new Point(752, 0);
            btnExportarPDF.Name = "btnExportarPDF";
            btnExportarPDF.Size = new Size(203, 35);
            btnExportarPDF.TabIndex = 0;
            btnExportarPDF.Text = "Descargar en PDF";
            btnExportarPDF.UseVisualStyleBackColor = false;
            btnExportarPDF.Click += BtnExportarPDF_Click;
            // 
            // FormDetalleCita
            // 
            ClientSize = new Size(967, 748);
            Controls.Add(btnExportarPDF);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(lblTitulo);
            Name = "FormDetalleCita";
            Text = "Detalle de la Cita";
            Load += FormDetalleCita_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
    }
}