﻿namespace PROYECTO__CITAS
{
    partial class FormMenuPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenuPrincipal));
            pictureBox1 = new PictureBox();
            btnSalir = new Button();
            btnAgendarCita = new Button();
            btnReprogramarCita = new Button();
            btnHistorialCita = new Button();
            btnRegistroMedicos = new Button();
            btnDiagnosticoIA = new Button();
            btnReporteGeneral = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = null;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(14, 133);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(507, 528);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnSalir
            // 
            btnSalir.BackColor = Color.FromArgb(74, 144, 226);
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = SystemColors.ButtonHighlight;
            btnSalir.Location = new Point(809, 644);
            btnSalir.Margin = new Padding(3, 4, 3, 4);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(119, 45);
            btnSalir.TabIndex = 0;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnAgendarCita
            // 
            btnAgendarCita.BackColor = Color.FromArgb(74, 144, 226);
            btnAgendarCita.FlatStyle = FlatStyle.Flat;
            btnAgendarCita.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAgendarCita.ForeColor = SystemColors.ButtonHighlight;
            btnAgendarCita.Location = new Point(538, 133);
            btnAgendarCita.Name = "btnAgendarCita";
            btnAgendarCita.Size = new Size(167, 76);
            btnAgendarCita.TabIndex = 1;
            btnAgendarCita.Text = "Agendar Cita";
            btnAgendarCita.UseVisualStyleBackColor = false;
            btnAgendarCita.Click += btnAgendarCita_Click;
            // 
            // btnReprogramarCita
            // 
            btnReprogramarCita.BackColor = Color.FromArgb(74, 144, 226);
            btnReprogramarCita.FlatStyle = FlatStyle.Flat;
            btnReprogramarCita.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReprogramarCita.ForeColor = SystemColors.ButtonHighlight;
            btnReprogramarCita.Location = new Point(538, 267);
            btnReprogramarCita.Name = "btnReprogramarCita";
            btnReprogramarCita.Size = new Size(167, 76);
            btnReprogramarCita.TabIndex = 2;
            btnReprogramarCita.Text = "Reprogramar Cita";
            btnReprogramarCita.UseVisualStyleBackColor = false;
            btnReprogramarCita.Click += btnReprogramarCita_Click;
            // 
            // btnHistorialCita
            // 
            btnHistorialCita.BackColor = Color.FromArgb(74, 144, 226);
            btnHistorialCita.FlatStyle = FlatStyle.Flat;
            btnHistorialCita.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnHistorialCita.ForeColor = SystemColors.ButtonHighlight;
            btnHistorialCita.Location = new Point(538, 400);
            btnHistorialCita.Name = "btnHistorialCita";
            btnHistorialCita.Size = new Size(167, 76);
            btnHistorialCita.TabIndex = 3;
            btnHistorialCita.Text = "Historial de Citas";
            btnHistorialCita.UseVisualStyleBackColor = false;
            btnHistorialCita.Click += btnHistorialCita_Click;
            // 
            // btnRegistroMedicos
            // 
            btnRegistroMedicos.BackColor = Color.FromArgb(74, 144, 226);
            btnRegistroMedicos.FlatStyle = FlatStyle.Flat;
            btnRegistroMedicos.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistroMedicos.ForeColor = SystemColors.ButtonHighlight;
            btnRegistroMedicos.Location = new Point(761, 133);
            btnRegistroMedicos.Name = "btnRegistroMedicos";
            btnRegistroMedicos.Size = new Size(167, 76);
            btnRegistroMedicos.TabIndex = 3;
            btnRegistroMedicos.Text = "Registro Medicos";
            btnRegistroMedicos.UseVisualStyleBackColor = false;
            btnRegistroMedicos.Click += btnRegistroMedico_Click;
            // 
            // btnDiagnosticoIA
            // 
            btnDiagnosticoIA.BackColor = Color.FromArgb(74, 144, 226);
            btnDiagnosticoIA.FlatStyle = FlatStyle.Flat;
            btnDiagnosticoIA.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDiagnosticoIA.ForeColor = SystemColors.ButtonHighlight;
            btnDiagnosticoIA.Location = new Point(761, 400);
            btnDiagnosticoIA.Name = "btnDiagnosticoIA";
            btnDiagnosticoIA.Size = new Size(167, 76);
            btnDiagnosticoIA.TabIndex = 4;
            btnDiagnosticoIA.Text = "Diagnóstico IA";
            btnDiagnosticoIA.UseVisualStyleBackColor = false;
            btnDiagnosticoIA.Click += btnDiagnosticoIA_Click;
            // 
            // btnReporteGeneral
            // 
            btnReporteGeneral.BackColor = Color.FromArgb(74, 144, 226);
            btnReporteGeneral.FlatStyle = FlatStyle.Flat;
            btnReporteGeneral.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReporteGeneral.ForeColor = SystemColors.ButtonHighlight;
            btnReporteGeneral.Location = new Point(761, 267);
            btnReporteGeneral.Name = "btnReporteGeneral";
            btnReporteGeneral.Size = new Size(167, 76);
            btnReporteGeneral.TabIndex = 5;
            btnReporteGeneral.Text = "Reporte General de Citas";
            btnReporteGeneral.UseVisualStyleBackColor = false;
            btnReporteGeneral.Click += btnReporteGeneral_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Handwriting", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(23, 48);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(516, 52);
            label1.TabIndex = 6;
            label1.Text = "Sistema Citas Medicas";
            label1.Click += label1_Click;
            // 
            // FormMenuPrincipal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 241, 249);
            ClientSize = new Size(967, 748);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(btnReporteGeneral);
            Controls.Add(btnDiagnosticoIA);
            Controls.Add(btnRegistroMedicos);
            Controls.Add(btnHistorialCita);
            Controls.Add(btnReprogramarCita);
            Controls.Add(btnAgendarCita);
            Controls.Add(btnSalir);
            Icon = (Icon)resources.GetObject("$this.Icon");
            ImeMode = ImeMode.On;
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormMenuPrincipal";
            Text = "Menú Principal";
            Load += FormMenuPrincipal_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnSalir;
        private Button btnAgendarCita;
        private Button btnReprogramarCita;
        private Button btnHistorialCita;
        private Button btnRegistroMedicos;
        private Button btnDiagnosticoIA;
        private Button btnReporteGeneral;
        private Label label1;
        private PictureBox pictureBox1;
    }
}
