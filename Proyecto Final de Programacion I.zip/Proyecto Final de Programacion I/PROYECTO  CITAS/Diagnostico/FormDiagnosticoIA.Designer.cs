﻿namespace PROYECTO__CITAS
{
    partial class FormDiagnosticoIA
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.txtSintomas = new System.Windows.Forms.TextBox();
            this.btnDiagnosticar = new System.Windows.Forms.Button();
            this.btnVerMedicamentos = new System.Windows.Forms.Button();
            this.lstDiagnosticos = new System.Windows.Forms.ListBox();
            this.dgvMedicamentos = new System.Windows.Forms.DataGridView();
            this.chartProbabilidades = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnNuevaConsulta = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMedicamentos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartProbabilidades)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSintomas
            // 
            this.txtSintomas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(250)))), ((int)(((byte)(251)))));
            this.txtSintomas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSintomas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSintomas.ForeColor = System.Drawing.Color.Black;
            this.txtSintomas.Location = new System.Drawing.Point(15, 71);
            this.txtSintomas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSintomas.Name = "txtSintomas";
            this.txtSintomas.Size = new System.Drawing.Size(533, 34);
            this.txtSintomas.TabIndex = 0;
            // 
            // btnDiagnosticar
            // 
            this.btnDiagnosticar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(144)))), ((int)(((byte)(226)))));
            this.btnDiagnosticar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDiagnosticar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDiagnosticar.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnDiagnosticar.Location = new System.Drawing.Point(561, 71);
            this.btnDiagnosticar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDiagnosticar.Name = "btnDiagnosticar";
            this.btnDiagnosticar.Size = new System.Drawing.Size(160, 36);
            this.btnDiagnosticar.TabIndex = 2;
            this.btnDiagnosticar.Text = "Diagnosticar";
            this.btnDiagnosticar.UseVisualStyleBackColor = false;
            this.btnDiagnosticar.Click += new System.EventHandler(this.btnDiagnosticar_Click);
            // 
            // btnVerMedicamentos
            // 
            this.btnVerMedicamentos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(144)))), ((int)(((byte)(226)))));
            this.btnVerMedicamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerMedicamentos.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerMedicamentos.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnVerMedicamentos.Location = new System.Drawing.Point(760, 342);
            this.btnVerMedicamentos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVerMedicamentos.Name = "btnVerMedicamentos";
            this.btnVerMedicamentos.Size = new System.Drawing.Size(337, 37);
            this.btnVerMedicamentos.TabIndex = 3;
            this.btnVerMedicamentos.Text = "Ver Medicamento";
            this.btnVerMedicamentos.UseVisualStyleBackColor = false;
            this.btnVerMedicamentos.Click += new System.EventHandler(this.btnVerMedicamentos_Click);
            // 
            // lstDiagnosticos
            // 
            this.lstDiagnosticos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(250)))), ((int)(((byte)(251)))));
            this.lstDiagnosticos.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDiagnosticos.FormattingEnabled = true;
            this.lstDiagnosticos.ItemHeight = 23;
            this.lstDiagnosticos.Location = new System.Drawing.Point(15, 137);
            this.lstDiagnosticos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstDiagnosticos.Name = "lstDiagnosticos";
            this.lstDiagnosticos.Size = new System.Drawing.Size(705, 165);
            this.lstDiagnosticos.TabIndex = 4;
            this.lstDiagnosticos.SelectedIndexChanged += new System.EventHandler(this.lstDiagnosticos_SelectedIndexChanged);
            // 
            // dgvMedicamentos
            // 
            this.dgvMedicamentos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(250)))), ((int)(((byte)(251)))));
            this.dgvMedicamentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMedicamentos.Location = new System.Drawing.Point(760, 71);
            this.dgvMedicamentos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvMedicamentos.Name = "dgvMedicamentos";
            this.dgvMedicamentos.ReadOnly = true;
            this.dgvMedicamentos.RowHeadersWidth = 51;
            this.dgvMedicamentos.RowTemplate.Height = 24;
            this.dgvMedicamentos.Size = new System.Drawing.Size(337, 246);
            this.dgvMedicamentos.TabIndex = 5;
            // 
            // chartProbabilidades
            // 
            this.chartProbabilidades.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(173)))), ((int)(((byte)(226)))));
            chartArea1.Name = "ChartArea1";
            this.chartProbabilidades.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartProbabilidades.Legends.Add(legend1);
            this.chartProbabilidades.Location = new System.Drawing.Point(15, 342);
            this.chartProbabilidades.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chartProbabilidades.Name = "chartProbabilidades";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Probabilidad ";
            this.chartProbabilidades.Series.Add(series1);
            this.chartProbabilidades.Size = new System.Drawing.Size(707, 308);
            this.chartProbabilidades.TabIndex = 6;
            this.chartProbabilidades.Text = "chart1";
            this.chartProbabilidades.Click += new System.EventHandler(this.chartProbabilidades_Click);
            // 
            // btnNuevaConsulta
            // 
            this.btnNuevaConsulta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(144)))), ((int)(((byte)(226)))));
            this.btnNuevaConsulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevaConsulta.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevaConsulta.ForeColor = System.Drawing.Color.LightYellow;
            this.btnNuevaConsulta.Location = new System.Drawing.Point(760, 407);
            this.btnNuevaConsulta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNuevaConsulta.Name = "btnNuevaConsulta";
            this.btnNuevaConsulta.Size = new System.Drawing.Size(337, 38);
            this.btnNuevaConsulta.TabIndex = 7;
            this.btnNuevaConsulta.Text = "Nueva Consulta";
            this.btnNuevaConsulta.UseVisualStyleBackColor = false;
            this.btnNuevaConsulta.Click += new System.EventHandler(this.btnNuevaConsulta_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(16, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ingrese Los Sintomas";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(241)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1128, 690);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnNuevaConsulta);
            this.Controls.Add(this.chartProbabilidades);
            this.Controls.Add(this.dgvMedicamentos);
            this.Controls.Add(this.lstDiagnosticos);
            this.Controls.Add(this.btnVerMedicamentos);
            this.Controls.Add(this.btnDiagnosticar);
            this.Controls.Add(this.txtSintomas);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Diagnóstico Médico";
            ((System.ComponentModel.ISupportInitialize)(this.dgvMedicamentos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartProbabilidades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSintomas;
        private System.Windows.Forms.Button btnDiagnosticar;
        private System.Windows.Forms.Button btnVerMedicamentos;
        private System.Windows.Forms.ListBox lstDiagnosticos;
        private System.Windows.Forms.DataGridView dgvMedicamentos;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartProbabilidades;
        private System.Windows.Forms.Button btnNuevaConsulta;
        private System.Windows.Forms.Label label1;
    }
}

