﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace PrOYECTO__CITAS
{
    /*internal class ServerOpenIA
    {
        static async Task Main()
        {
            var apiKey = "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"; // Reemplaza con tu clave de API
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            var request = new ChatRequest
            {
                model = "gpt-4.1",
                messages = new[]
                {
                new Message { role = "user", content = "Write a one-sentence bedtime story about a unicorn." }
            }
            };

            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);
            var responseString = await response.Content.ReadAsStringAsync();

            var chatResponse = JsonSerializer.Deserialize<ChatResponse>(responseString);

            Console.WriteLine("Respuesta:");
            Console.WriteLine(chatResponse?.choices?[0]?.message?.content ?? "Sin respuesta");
        }
    }

    // --- Clases para solicitud ---
    public class ChatRequest
    {
        public string model { get; set; }
        public Message[] messages { get; set; }
    }

    public class Message
    {
        public string role { get; set; }
        public string content { get; set; }
    }

    // --- Clases para respuesta ---
    public class ChatResponse
    {
        public Choice[] choices { get; set; }
    }

    public class Choice
    {
        public Message message { get; set; }
    }
    */
}

