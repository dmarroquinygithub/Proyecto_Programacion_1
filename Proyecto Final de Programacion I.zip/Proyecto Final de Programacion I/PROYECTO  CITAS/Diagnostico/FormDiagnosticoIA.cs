﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json.Serialization;

namespace PROYECTO__CITAS
{
    public partial class FormDiagnosticoIA : Form
    {
        private readonly HttpClient httpClient;
        public FormDiagnosticoIA()
        {
            InitializeComponent();
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "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");
        }

        private async void btnDiagnosticar_Click(object sender, EventArgs e)
        {
            string sintomas = txtSintomas.Text.Trim();

            if (string.IsNullOrWhiteSpace(sintomas))
            {
                MessageBox.Show("Por favor, ingresa los síntomas.");
                return;
            }

            string prompt = $"Dado los siguientes síntomas: {sintomas}, " +
                            "menciona las 5 enfermedades más probables con un porcentaje estimado. " +
                            "Devuelve únicamente un objeto JSON con formato así: " +
                            "{ \"Gripe\": 40, \"COVID-19\": 25, \"Alergia\": 15, \"Sinusitis\": 10, \"Faringitis\": 10 }";

            var request = new ChatRequest
            {
                model = "gpt-4",
                messages = new[]
                {
            new Message { role = "user", content = prompt }
        }
            };

            var json = JsonSerializer.Serialize(request);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);
                var responseString = await response.Content.ReadAsStringAsync();

                var chatResponse = JsonSerializer.Deserialize<ChatResponse>(responseString);
                var respuestaGPT = chatResponse?.choices?[0]?.message?.content?.Trim();

                if (string.IsNullOrWhiteSpace(respuestaGPT) || !respuestaGPT.StartsWith("{"))
                {
                    MessageBox.Show("La IA no devolvió un JSON válido:\n" + respuestaGPT);
                    return;
                }

                MostrarDiagnosticos(respuestaGPT);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el diagnóstico:\n" + ex.Message);
            }
        }


        private void MostrarDiagnosticos(string respuesta)
        {
            try
            {
                lstDiagnosticos.Items.Clear();
                chartProbabilidades.Series.Clear();

                // Se limpian las respuestas por si agrega con símbolos extras
                respuesta = respuesta.Trim('`', '\n', '\r', ' ');

                var enfermedades = JsonSerializer.Deserialize<Dictionary<string, int>>(respuesta);

                var serie = chartProbabilidades.Series.Add("Probabilidad");
                serie.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;

                foreach (var enfermedad in enfermedades)
                {
                    lstDiagnosticos.Items.Add($"{enfermedad.Key} ({enfermedad.Value}%)");
                    serie.Points.AddXY(enfermedad.Key, enfermedad.Value);
                }

                btnVerMedicamentos.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al interpretar la respuesta de la IA:\n" + ex.Message);
            }
        }
        
      

        private async void btnVerMedicamentos_Click(object sender, EventArgs e)
        {
            if (lstDiagnosticos.SelectedItem == null)
            {
                MessageBox.Show("Selecciona una enfermedad primero.");
                return;
            }

            string enfermedadSeleccionada = lstDiagnosticos.SelectedItem.ToString();
            enfermedadSeleccionada = enfermedadSeleccionada.Split('(')[0].Trim(); // Elimina el porcentaje

            string promptMedicamentos = $"Dime los medicamentos más usados para tratar {enfermedadSeleccionada}. " +
                                        "Respóndelo únicamente como un objeto JSON de esta forma: " +
                                        "{ \"Paracetamol\": \"500mg cada 8 horas\", \"Ibuprofeno\": \"400mg cada 12 horas\" }. " +
                                        "No agregues texto adicional.";

            var requestMedicamentos = new ChatRequest
            {
                model = "gpt-4",
                messages = new[]
                {
            new Message { role = "user", content = promptMedicamentos }
        }
            };

            var jsonMedicamentos = JsonSerializer.Serialize(requestMedicamentos);
            var contentMedicamentos = new StringContent(jsonMedicamentos, Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync("https://api.openai.com/v1/chat/completions", contentMedicamentos);
                var responseString = await response.Content.ReadAsStringAsync();

                var chatResponse = JsonSerializer.Deserialize<ChatResponse>(responseString);
                var respuestaGPT = chatResponse?.choices?[0]?.message?.content?.Trim();

                if (string.IsNullOrWhiteSpace(respuestaGPT) || !respuestaGPT.StartsWith("{"))
                {
                    MessageBox.Show("La IA no devolvió un JSON válido:\n" + respuestaGPT);
                    return;
                }

                var medicamentos = JsonSerializer.Deserialize<Dictionary<string, string>>(respuestaGPT);

                dgvMedicamentos.Rows.Clear();
                dgvMedicamentos.Columns.Clear();
                dgvMedicamentos.Columns.Add("Medicamento", "Medicamento");
                dgvMedicamentos.Columns.Add("Dosis", "Dosis");

                foreach (var item in medicamentos)
                {
                    dgvMedicamentos.Rows.Add(item.Key, item.Value);
                }

                // Aparece un mensaje de si se equiere cirugía segun la IA 
                string promptCirugia = $"¿La enfermedad {enfermedadSeleccionada} puede requerir cirugía o intervención quirúrgica? " +
                                       "Respóndelo con una sola línea clara como: \"Sí, requiere cirugía\" o \"No, no requiere cirugía\".";

                var requestCirugia = new ChatRequest
                {
                    model = "gpt-4",
                    messages = new[]
                    {
                new Message { role = "user", content = promptCirugia }
            }
                };

                var jsonCirugia = JsonSerializer.Serialize(requestCirugia);
                var contentCirugia = new StringContent(jsonCirugia, Encoding.UTF8, "application/json");

                var responseCirugia = await httpClient.PostAsync("https://api.openai.com/v1/chat/completions", contentCirugia);
                var responseCirugiaString = await responseCirugia.Content.ReadAsStringAsync();

                var chatResponseCirugia = JsonSerializer.Deserialize<ChatResponse>(responseCirugiaString);
                var respuestaCirugia = chatResponseCirugia?.choices?[0]?.message?.content?.Trim();

                if (!string.IsNullOrWhiteSpace(respuestaCirugia))
                {
                    MessageBox.Show("Evaluación quirúrgica:\n" + respuestaCirugia, "Posible Cirugía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar a la IA:\n" + ex.Message);
            }
        }

        private void MostrarMedicamentos(string respuesta)
        {
            try
            {
                var medicamentos = JsonSerializer.Deserialize<List<string>>(respuesta);

                dgvMedicamentos.Columns.Clear();
                dgvMedicamentos.Rows.Clear();
                dgvMedicamentos.Columns.Add("Medicamento", "Medicamento");

                foreach (var med in medicamentos)
                {
                    dgvMedicamentos.Rows.Add(med);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al interpretar la lista de medicamentos:\n" + ex.Message);
            }
        }

        private void btnNuevaConsulta_Click(object sender, EventArgs e)
        {
            txtSintomas.Clear();

            lstDiagnosticos.Items.Clear();

            chartProbabilidades.Series.Clear();

            dgvMedicamentos.Columns.Clear();

            dgvMedicamentos.Rows.Clear();

            btnVerMedicamentos.Visible = false;
        }

        private void lstDiagnosticos_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Se coloco al darle click a un diagnóstico
        }

        private void chartProbabilidades_Click(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al gráfico
        }
    }

    public class ChatRequest
    {
        public string model { get; set; }
        public Message[] messages { get; set; }
    }

    public class Message
    {
        public string role { get; set; }
        public string content { get; set; }
    }

    public class ChatResponse
    {
        public Choice[] choices { get; set; }
    }

    public class Choice
    {
        public Message message { get; set; }
    }
}
