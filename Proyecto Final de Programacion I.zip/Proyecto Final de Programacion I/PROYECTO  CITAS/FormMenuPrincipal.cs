namespace PROYECTO__CITAS
{
    public partial class FormMenuPrincipal : Form
    {
        public FormMenuPrincipal()
        {
            InitializeComponent();
        }



        private void btnAgendarCita_Click(object sender, EventArgs e)
        {
            FormAgendarCita agendar = new FormAgendarCita();
            agendar.Show();
        }

        private void btnRegistroMedico_Click(object sender, EventArgs e)
        {
            FormRegistroMedico registro = new FormRegistroMedico();
            registro.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {

            DialogResult resultado = MessageBox.Show("�Est�s seguro que deseas salir?", "Confirmar salida", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnReprogramarCita_Click(object sender, EventArgs e)
        {
            FormReprogramarCita form = new FormReprogramarCita();
            form.Show();
        }

        private void btnDiagnosticoIA_Click(object sender, EventArgs e)
        {
            FormDiagnosticoIA form = new FormDiagnosticoIA();
            form.Show();
        }

        private void btnHistorialCita_Click(object sender, EventArgs e)
        {
            FormHistorialCita form = new FormHistorialCita();
            form.Show();
        }

        private void btnReporteGeneral_Click(object sender, EventArgs e)
        {
            FormReporteGeneral form = new FormReporteGeneral();
            form.Show();
        }

        private void FormMenuPrincipal_Load(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al form de la aplicacion
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al label de el sistema de citas
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Se coloco al darle doble click a la imagen de el logo del sistema de citas
        }
    }
}
