using System.Globalization;
using System;
using System.Windows.Forms;
using System.Threading;

namespace PROYECTO__CITAS
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();  // ? Esto reemplaza ApplicationConfiguration
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMenuPrincipal());  // Aseg�rate de que este formulario exista
        }

    }
}
