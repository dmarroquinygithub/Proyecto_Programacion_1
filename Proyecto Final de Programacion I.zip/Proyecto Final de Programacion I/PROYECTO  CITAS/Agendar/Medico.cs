﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO__CITAS.Agendar
{
    internal class Medico
    {
            public int IdMedico { get; set; }
            public string Nombre { get; set; }
        }
    }

