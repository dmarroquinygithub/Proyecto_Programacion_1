﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO__CITAS.Agendar
{
    internal class Cita
    {
        public string NombrePaciente { get; set; }
        public string ApellidoPaciente { get; set; }
        public string Telefono { get; set; }
        public string DPI { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Sexo { get; set; }
        public DateTime FechaCita { get; set; }
        public TimeSpan Hora { get; set; }
        public string Motivo { get; set; }
        public int IdMedico { get; set; }
    }
}
