﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;


namespace PROYECTO__CITAS.Agendar
{
    internal class CitaRepository
    {
        public void AgendarCita(Cita cita)
        {
            string query = @"INSERT INTO Citas 
                (nombre_paciente, apellido_paciente, telefono, dpi, fecha_nacimiento, sexo, fecha_cita, hora, motivo, id_medico)
                VALUES 
                (@nombre, @apellido, @telefono, @dpi, @nacimiento, @sexo, @fecha, @hora, @motivo, @id_medico)";

            using (var conexion = ConexionBD.ObtenerConexion())
            {
                MySqlCommand cmd = new MySqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@nombre", cita.NombrePaciente);
                cmd.Parameters.AddWithValue("@apellido", cita.ApellidoPaciente);
                cmd.Parameters.AddWithValue("@telefono", cita.Telefono);
                cmd.Parameters.AddWithValue("@dpi", cita.DPI);
                cmd.Parameters.AddWithValue("@nacimiento", cita.FechaNacimiento);
                cmd.Parameters.AddWithValue("@sexo", cita.Sexo);
                cmd.Parameters.AddWithValue("@fecha", cita.FechaCita);
                cmd.Parameters.AddWithValue("@hora", cita.Hora);
                cmd.Parameters.AddWithValue("@motivo", cita.Motivo);
                cmd.Parameters.AddWithValue("@id_medico", cita.IdMedico);
                cmd.ExecuteNonQuery();
            }
        }

        public DataTable ObtenerCitas()
        {
            string query = @"SELECT c.id_cita, c.nombre_paciente, c.apellido_paciente, 
                             c.fecha_cita, c.hora, m.nombre AS medico 
                             FROM Citas c 
                             JOIN Medicos m ON c.id_medico = m.id_medico";

            using (var conexion = ConexionBD.ObtenerConexion())
            {
                MySqlDataAdapter da = new MySqlDataAdapter(query, conexion);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataTable ObtenerMedicos()
        {
            string query = "SELECT id_medico, nombre FROM Medicos";
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                MySqlDataAdapter da = new MySqlDataAdapter(query, conexion);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}

