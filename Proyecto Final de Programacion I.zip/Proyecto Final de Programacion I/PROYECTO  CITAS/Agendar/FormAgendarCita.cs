﻿using System;
using System.Data;
using System.Windows.Forms;
using PROYECTO__CITAS.Agendar;

namespace PROYECTO__CITAS
{
    public partial class FormAgendarCita : Form
    {
        private CitaRepository repo = new CitaRepository();

        public FormAgendarCita()
        {
            InitializeComponent();
        }

        private void FormAgendarCita_Load(object sender, EventArgs e)
        {
            CargarMedicos();
            MostrarCitas();
            dgvCitas.DataSource = null;
            this.BackColor = Color.FromArgb(232, 241, 249);
        }

        private void CargarMedicos()
        {
            cbMedico.DataSource = repo.ObtenerMedicos();
            cbMedico.DisplayMember = "nombre";
            cbMedico.ValueMember = "id_medico";
        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            var cita = new Cita
            {
                NombrePaciente = txtNombre.Text,
                ApellidoPaciente = txtApellido.Text,
                Telefono = txtTelefono.Text,
                DPI = txtDPI.Text,
                FechaNacimiento = dtpNacimiento.Value.Date,
                Sexo = cbSexo.Text,
                FechaCita = dtpFechaCita.Value.Date,
                Hora = dtpHora.Value.TimeOfDay,
                Motivo = txtMotivo.Text,
                IdMedico = Convert.ToInt32(cbMedico.SelectedValue)
            };

            repo.AgendarCita(cita);
            MessageBox.Show("Cita agendada correctamente.");

            MostrarCitas();
            LimpiarCampos();

            dgvCitas.DataSource = null;
            dgvCitas.DataSource = repo.ObtenerCitas();
        }

        private void dgvCitas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvCitas.DataSource = repo.ObtenerCitas();
        }

        private void MostrarCitas()
        {
            dgvCitas.DataSource = repo.ObtenerCitas();
        }
        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtTelefono.Clear();
            txtDPI.Clear();
            txtMotivo.Clear();
            cbSexo.SelectedIndex = -1;
            cbMedico.SelectedIndex = -1;
            dtpNacimiento.Value = DateTime.Today;
            dtpFechaCita.Value = DateTime.Today;
            dtpHora.Value = DateTime.Now;
        }

        private void dtpNacimiento_ValueChanged(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al data de la aplicacion
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al label 
        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al textbox del telefono
        }

    }
}