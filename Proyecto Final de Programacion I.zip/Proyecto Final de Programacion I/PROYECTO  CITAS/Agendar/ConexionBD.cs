﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PROYECTO__CITAS.Agendar
{
    internal class ConexionBD
    {
        private const string connectionString = "server=localhost;database=CitasMedicasDB;uid=root;pwd=123456789;";

        public static MySqlConnection ObtenerConexion()
        {
            var conexion = new MySqlConnection(connectionString);
            conexion.Open();
            return conexion;
        }
     }
}
