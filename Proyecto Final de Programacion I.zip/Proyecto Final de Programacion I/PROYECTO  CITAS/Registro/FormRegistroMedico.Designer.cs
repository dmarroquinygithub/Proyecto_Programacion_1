﻿namespace PROYECTO__CITAS
{
    partial class FormRegistroMedico
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            txtCorreo = new TextBox();
            txtDPI = new TextBox();
            txtTelefono = new TextBox();
            txtEspecialidad = new TextBox();
            txtNombre = new TextBox();
            btnRegistrar = new Button();
            dgvMedicos = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnEliminar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvMedicos).BeginInit();
            SuspendLayout();
            // 
            // txtCorreo
            // 
            txtCorreo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtCorreo.Location = new Point(338, 196);
            txtCorreo.Margin = new Padding(3, 4, 3, 4);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(270, 27);
            txtCorreo.TabIndex = 0;
            txtCorreo.TextChanged += txtCorreo_TextChanged;
            // 
            // txtDPI
            // 
            txtDPI.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            txtDPI.Location = new Point(721, 67);
            txtDPI.Margin = new Padding(3, 4, 3, 4);
            txtDPI.Name = "txtDPI";
            txtDPI.Size = new Size(220, 27);
            txtDPI.TabIndex = 1;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(33, 196);
            txtTelefono.Margin = new Padding(3, 4, 3, 4);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(258, 27);
            txtTelefono.TabIndex = 2;
            // 
            // txtEspecialidad
            // 
            txtEspecialidad.Location = new Point(338, 67);
            txtEspecialidad.Margin = new Padding(3, 4, 3, 4);
            txtEspecialidad.Name = "txtEspecialidad";
            txtEspecialidad.Size = new Size(313, 27);
            txtEspecialidad.TabIndex = 3;
            txtEspecialidad.TextChanged += txtEspecialidad_TextChanged;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(33, 67);
            txtNombre.Margin = new Padding(3, 4, 3, 4);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(261, 27);
            txtNombre.TabIndex = 4;
            // 
            // btnRegistrar
            // 
            btnRegistrar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRegistrar.BackColor = Color.FromArgb(74, 144, 226);
            btnRegistrar.FlatStyle = FlatStyle.Flat;
            btnRegistrar.Font = new Font("Arial", 13.8F);
            btnRegistrar.ForeColor = Color.White;
            btnRegistrar.Location = new Point(715, 253);
            btnRegistrar.Margin = new Padding(3, 4, 3, 4);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(226, 43);
            btnRegistrar.TabIndex = 5;
            btnRegistrar.Text = "Registrar Médico";
            btnRegistrar.UseVisualStyleBackColor = false;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // dgvMedicos
            // 
            dgvMedicos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvMedicos.BackgroundColor = Color.FromArgb(249, 250, 251);
            dgvMedicos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMedicos.Location = new Point(33, 339);
            dgvMedicos.Margin = new Padding(3, 4, 3, 4);
            dgvMedicos.Name = "dgvMedicos";
            dgvMedicos.RowHeadersWidth = 51;
            dgvMedicos.Size = new Size(907, 377);
            dgvMedicos.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F);
            label1.Location = new Point(33, 27);
            label1.Name = "label1";
            label1.Size = new Size(208, 26);
            label1.TabIndex = 7;
            label1.Text = "Nombre del Médico";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F);
            label2.Location = new Point(721, 27);
            label2.Name = "label2";
            label2.Size = new Size(56, 26);
            label2.TabIndex = 8;
            label2.Text = "DPI ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 13.8F);
            label3.Location = new Point(33, 153);
            label3.Name = "label3";
            label3.Size = new Size(213, 26);
            label3.TabIndex = 9;
            label3.Text = "Teléfono del Médico";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 13.8F);
            label4.Location = new Point(338, 27);
            label4.Name = "label4";
            label4.Size = new Size(220, 26);
            label4.TabIndex = 10;
            label4.Text = "Especialidad Médica";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 13.8F);
            label5.Location = new Point(338, 153);
            label5.Name = "label5";
            label5.Size = new Size(201, 26);
            label5.TabIndex = 11;
            label5.Text = "Correo electrónico";
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.FromArgb(74, 144, 226);
            btnEliminar.FlatStyle = FlatStyle.Flat;
            btnEliminar.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEliminar.ForeColor = SystemColors.ButtonHighlight;
            btnEliminar.Location = new Point(33, 253);
            btnEliminar.Margin = new Padding(3, 4, 3, 4);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(226, 43);
            btnEliminar.TabIndex = 12;
            btnEliminar.Text = "Eliminar Médico";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // FormRegistroMedico
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 241, 249);
            ClientSize = new Size(967, 748);
            Controls.Add(btnEliminar);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvMedicos);
            Controls.Add(btnRegistrar);
            Controls.Add(txtNombre);
            Controls.Add(txtEspecialidad);
            Controls.Add(txtTelefono);
            Controls.Add(txtDPI);
            Controls.Add(txtCorreo);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormRegistroMedico";
            Text = "FormRegistroMedico";
            Load += FormRegistroMedico_Load_1;
            ((System.ComponentModel.ISupportInitialize)dgvMedicos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCorreo;
        private TextBox txtDPI;
        private TextBox txtTelefono;
        private TextBox txtEspecialidad;
        private TextBox txtNombre;
        private Button btnRegistrar;
        private DataGridView dgvMedicos;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnEliminar;
    }
}
