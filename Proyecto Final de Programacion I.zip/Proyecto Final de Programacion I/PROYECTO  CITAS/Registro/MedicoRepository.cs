﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Registro;
using PROYECTO__CITAS.Agendar;

namespace PROYECTO__CITAS.Registro
{
    internal class MedicoRepository
    {
        public void RegistrarMedico(Medico medico)
        {
            string query = @"INSERT INTO Medicos (nombre, especialidad, telefono, correo, dpi)
                             VALUES (@nombre, @especialidad, @telefono, @correo, @dpi)";

            using (var conexion = ConexionBD.ObtenerConexion())
            {
                MySqlCommand cmd = new MySqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@nombre", medico.Nombre);
                cmd.Parameters.AddWithValue("@especialidad", medico.Especialidad);
                cmd.Parameters.AddWithValue("@telefono", medico.Telefono);
                cmd.Parameters.AddWithValue("@correo", medico.Correo);
                cmd.Parameters.AddWithValue("@dpi", medico.DPI);
                cmd.ExecuteNonQuery();
            }
        }

        public DataTable ObtenerMedicos()
        {
            string query = "SELECT id_medico, nombre, especialidad, telefono, correo, dpi FROM Medicos";
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                MySqlDataAdapter da = new MySqlDataAdapter(query, conexion);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;


            }
        }
        public void EliminarMedico(int idMedico)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
              
                string query = "DELETE FROM Medicos WHERE id_medico = @id";
                using (var cmd = new MySqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@id", idMedico);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}

