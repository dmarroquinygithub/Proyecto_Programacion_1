﻿using System;
using System.Data;
using System.Windows.Forms;
using PROYECTO__CITAS.Historial;
using MySql.Data.MySqlClient;
using PROYECTO__CITAS.Registro;

namespace PROYECTO__CITAS
{
    public partial class FormRegistroMedico : Form
    {
        private MedicoRepository repo = new MedicoRepository();

        public FormRegistroMedico()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            var medico = new Medico
            {
                Nombre = txtNombre.Text,
                Especialidad = txtEspecialidad.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text,
                DPI = txtDPI.Text
            };

            try
            {
                repo.RegistrarMedico(medico);
                MessageBox.Show("Médico registrado correctamente.");
                MostrarMedicos();
                LimpiarCampos();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void MostrarMedicos()
        {
            dgvMedicos.DataSource = repo.ObtenerMedicos();
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtEspecialidad.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtDPI.Clear();
        }

        private void txtEspecialidad_TextChanged(object sender, EventArgs e)
        {
            // Se coloco al darle doble click al texto de la especialidad
        }

        private void txtCorreo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void FormRegistroMedico_Load(object sender, EventArgs e)
        {
            MostrarMedicos();
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvMedicos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un médico para eliminar.");
                return;
            }

            var idMedico = Convert.ToInt32(dgvMedicos.SelectedRows[0].Cells["id_medico"].Value);

            var confirm = MessageBox.Show("¿Está seguro de que desea eliminar este médico?", "Confirmar eliminación", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                try
                {
                    repo.EliminarMedico(idMedico);
                    MessageBox.Show("Médico eliminado correctamente.");
                    MostrarMedicos();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error al eliminar: " + ex.Message);
                }
            }
        }

        private void FormRegistroMedico_Load_1(object sender, EventArgs e)
        {
            MostrarMedicos();
        }
    }
}